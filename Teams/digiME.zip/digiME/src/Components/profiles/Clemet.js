import React from "react";

import FadeIn from "react-fade-in";
import profilePic from "../../__public/clemet.png";
import twitterIcon from "../../__public/twitterIcon.png";
import facebookIcon from "../../__public/facebookIcon.png";
import instagramIcon from "../../__public/instagramIcon.png";
import linkedinIcon from "../../__public/linkedinIcon.png";
import slackIcon from "../../__public/slackIcon.png";

class Profile extends React.Component {
  constructor(props) {
    super(props);

    //State storage - should be hooked up with mongoose

    //We use OnLoadPost to get latest stored DB post. Intended to use with cancel button.
    this.state = {
      firstName: "Clemet",
      lastName: "Wengen",
      profilePic: profilePic,
      profileDescription:
        "I joined digiME to be available professionally. By snapping a photo of me you can get in touch with me on many different platforms",
      profileCV:
        "Professional experience \n Bouvet – Lead Developer (September 2010 – Present) \n Steadfast AS - SAP CRM Technical Consultant, October 2010 - Present \n SPV AG - SAP CRM Technical Consultant, April 2008 - September 2010 \n Media-Saturn Systemzentrale GmbH – Intern, March 2006 - July 2006 \n  Bauer AG – Apprenticeship, September 2000 - September 2003 \n  Education \n       Ulster University - Exchange, Business and Management · (2007 - 2008) \n Fachhochschule Augsburg (2003 - 2008) \n  Top Skills \n •	ABAP \n  •	SAP \n  •	SAP CRM "
    };
 
    this.backButton = this.backButton.bind(this);
  }

  componentWillMount() {}

  componentDidMount() {}
  backButton(){
    window.location.replace("/");
  }

  render() {
    return (
      <FadeIn>
        <button className="btn btn-warning backButton" onClick={this.backButton}>Back</button>
        <div className="profileSpacer"></div>
        <div className="profileWrapper">
          <div className="card">
            <h1 className="profileTitle">
              {this.state.firstName} {this.state.lastName}
            </h1>
          </div>

          <div className="row">
            <div className="column col-sm-3">
              <div className="profilePicWrapper">
                <img src={this.state.profilePic} alt="profilepic" />
              </div>

              <div className="profileDescriptionWrapper smallCard">
                <h3>Find me on</h3>
                <div>
                  <img className="soMeIcon" src={slackIcon} alt="slack" />
                  <img className="soMeIcon" src={facebookIcon} alt="facebook" />
                  <img
                    className="soMeIcon"
                    src={instagramIcon}
                    alt="instagram"
                  />
                  <img className="soMeIcon" src={linkedinIcon} alt="linkedin" />
                </div>
              </div>

              <div className="smallSpacer">
                <div className="profileDescriptionWrapper smallCard">
                  <h3>Contact me</h3>
                  <br />
                  <div>
                    <h5>Phone</h5>

                    <p>+47 92687481</p>
                    <br />
                    <h5>Email</h5>

                    <p>clemetw@gmail.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="column col-sm-7 profileSpacer">
              <div className="profileDescriptionWrapper card">
                <h3>Status</h3>
                <br />
                <h5>
                  Currently attending{" "}
                  <a href="https://events.sap.com/eur/coil-ml-hackathon-eu-north/en/registration.aspx">
                    SAP ML Hackathon!
                  </a>{" "}
                </h5>
                <hr />
              </div>
              <div className="profileDescriptionWrapper card">
                <h3>Description</h3>
                <p>{this.state.profileDescription}</p>
                <hr />
              </div>

              <div className="profileDescriptionWrapper card">
                <h3>CV</h3>
                <br />
                <p>
                  <h5>Professional experience:</h5>
                  <ul>
                    <li>
                      Bouvet ASA SAP Consultant – Developer - september 2017 -
                      Present
                    </li>
                    <li>Cognizant IT-Consultant - januar 2015 - august 2017</li>
                    <li>
                      Elkjop Nordic AS (Part of Dixons Carphone plc) 2008 - 2015
                    </li>
                  </ul>
                  <h5>Education</h5>
                  <ul>
                    <li>
                      Høgskolen i Østfold / Østfold University College (HiØ) -
                      Bachelor's degree, Information Systems & IT management ·
                      (2009 - 2013)
                    </li>
                  </ul>
                  <h5>Top skills</h5>
                  <ul>
                    <li>React </li>
                    <li>C# </li>
                    <li>Web</li>
                  </ul>
                </p>
                <hr />
              </div>
              <div className="profileDescriptionWrapper card">
                <h3>Articles</h3>
                <p>
                  <ul>I will upload something more relevant later!</ul>
                </p>
                <hr />
              </div>
            </div>

            <div className="column col-sm-2 alignRight">
              <div className="profileSideBarWrapper card">
                <center>
                  <h3>About:</h3>
                </center>
                <br />
                <h5>Work:</h5>
                <ul>
                  <li> Developer Bouvet </li>
                </ul>
                <br />
                <h5>Education:</h5>
                <ul>
                  <li>Høgskolen i Østfold</li>
                </ul>
                <br />
                <h5>Age: </h5>
                <ul>
                  <li> 28</li>
                </ul>
                <br />
                <h5>Join date:</h5>
                <ul>
                  <li>26.09.2019 </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    );
  }
}

export default Profile;
