import React from "react";

import FadeIn from "react-fade-in";
import profilePic from "../../__public/kjetil.jpg";
import twitterIcon from "../../__public/twitterIcon.png";
import facebookIcon from "../../__public/facebookIcon.png";
import instagramIcon from "../../__public/instagramIcon.png";
import linkedinIcon from "../../__public/linkedinIcon.png";

class Profile extends React.Component {
  constructor(props) {
    super(props);

    //State storage - should be hooked up with mongoose

    //We use OnLoadPost to get latest stored DB post. Intended to use with cancel button.
    this.state = {
      firstName: "Kjetil",
      lastName: "Nordli",
      profilePic: profilePic,
      profileDescription:
        "Not much to share at the moment",
      profileCV:
        "Professional experience \n Bouvet – Lead Developer (September 2010 – Present) \n Steadfast AS - SAP CRM Technical Consultant, October 2010 - Present \n SPV AG - SAP CRM Technical Consultant, April 2008 - September 2010 \n Media-Saturn Systemzentrale GmbH – Intern, March 2006 - July 2006 \n  Bauer AG – Apprenticeship, September 2000 - September 2003 \n  Education \n       Ulster University - Exchange, Business and Management · (2007 - 2008) \n Fachhochschule Augsburg (2003 - 2008) \n  Top Skills \n •	ABAP \n  •	SAP \n  •	SAP CRM "
    };
    this.backButton = this.backButton.bind(this);
  }

  componentWillMount() {}

  componentDidMount() {}
  backButton(){
    window.location.replace("/");
  }

  render() {
    return (
      <FadeIn>
        <button className="btn btn-warning backButton" onClick={this.backButton}>Back</button>
        <div className="profileSpacer"></div>
        <div className="profileWrapper">
          <div className="card">
            <h1 className="profileTitle">
              {this.state.firstName} {this.state.lastName}
            </h1>
          </div>

          <div className="row">
            <div className="column col-sm-3">
              <div className="profilePicWrapper">
                <img src={this.state.profilePic} alt="profilepic" />
              </div>

              <div className="profileDescriptionWrapper smallCard">
                <h3>Find me on</h3>
                <div>
                  <img className="soMeIcon" src={twitterIcon} alt="twitter" />
                  <img className="soMeIcon" src={facebookIcon} alt="facebook" />
                  <img
                    className="soMeIcon"
                    src={instagramIcon}
                    alt="instagram"
                  />
                  <img className="soMeIcon" src={linkedinIcon} alt="linkedin" />
                </div>
              </div>
            </div>

            <div className="column col-sm-7 profileSpacer">
              <div className="profileDescriptionWrapper card">
                <h3>Status</h3>
                <br />
                <h5>
                  Currently attending{" "}
                  <a href="https://events.sap.com/eur/coil-ml-hackathon-eu-north/en/registration.aspx">
                    SAP ML Hackathon!
                  </a>{" "}
                </h5>
                <hr />
              </div>
              <div className="profileDescriptionWrapper card">
                <h3>Description</h3>
                <p>{this.state.profileDescription}</p>
                <hr />
              </div>

              <div className="profileDescriptionWrapper card">
                <h3>CV</h3>
                <br/>
                <p>
                  <h5>Profssional experience:</h5>
                  <ul>
                    <li>

                    EY Skye Consulting AS - Senior SAP Consultant, IBM Bluemix Consultant - February 2017 -> Present 
                    </li>
                    <li>
                    EVRY ASA - Senior SAP Consultant, April 2012 - February 2017 
                    </li>
                    <li>
                    Spring SAP Services, EDB Consulting Group - SAP Consultant - January 2010 - September 2012 
                    </li>
                    <li>
                    KMD – Consultant, 2011 - 2012 
                    </li>
                    <li>
                    EDB ErgoGroup ASA - SAP Consultant, 2010 - 2012
                    </li>
                  </ul>
                  <h5>Education</h5>
                  <ul>
                    <li>
                    QUT (Queensland University of Technology)- Master of IT, Project Management, SAP, IT Secuity · (2006 - 2007)
                    </li>
                    Østfold University College (HiØ) - Bachelor, Information Technology, English and International Business
                  </ul>
                  <h5>Top skills</h5>
                  <ul>
                    <li>SAP ERP </li>
                    <li>WebDynpro </li>
                    <li>ABAP </li>
                  </ul>
                </p>
                <hr/>
              </div>
              <div className="profileDescriptionWrapper card">
                <h3>Articles</h3>
                <p>
                  <ul>
                <li> <a href="https://www.sap-sbn.no/files/2018/iot_2018_bouvet_001.pdf" target="_blank" rel="noopener noreferrer">Internet of things - Maintenance</a></li>
                <li> <a href="https://www.sap-sbn.no/files/2018/iot_2018_bouvet_001.pdf" target="_blank" rel="noopener noreferrer">GDPR – Latest news and experiences</a></li>
                  </ul>
                </p>
                <hr />
              </div>
            </div>

            <div className="column col-sm-2 alignRight">
              <div className="profileSideBarWrapper card">
                <center>
                  <h3>About:</h3>
                </center>
                <br />
                <h5>Work:</h5>
                <ul>
                  <li> Developer</li>
                  </ul>
                  <br />
                  <h5>Age: </h5>
                  <ul>
          
                  <li> Not telling            
                  </li>
                  </ul>
                  <br />
                  <h5>Join date:</h5>
                  <ul>
                  <li>
                    26.09.2019{" "}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    );
  }
}

export default Profile;
