import React from "react";

import FadeIn from "react-fade-in";
import profilePic from "../../__public/kenneth.jpg";
import twitterIcon from "../../__public/twitterIcon.png";
import facebookIcon from "../../__public/facebookIcon.png";
import instagramIcon from "../../__public/instagramIcon.png";
import linkedinIcon from "../../__public/linkedinIcon.png";
import tinderIcon from "../../__public/tinderIcon.png";
import snapchatIcon from "../../__public/snapchatIcon.png";

class Profile extends React.Component {
  constructor(props) {
    super(props);

    //State storage - should be hooked up with mongoose

    //We use OnLoadPost to get latest stored DB post. Intended to use with cancel button.
    this.state = {
      firstName: "Kenneth",
      lastName: "Wolstrup",
      profilePic: profilePic,
      profileDescription:
        "Add me on snapchat :D",
      profileCV:
        "Professional experience \n Bouvet – Lead Developer (September 2010 – Present) \n Steadfast AS - SAP CRM Technical Consultant, October 2010 - Present \n SPV AG - SAP CRM Technical Consultant, April 2008 - September 2010 \n Media-Saturn Systemzentrale GmbH – Intern, March 2006 - July 2006 \n  Bauer AG – Apprenticeship, September 2000 - September 2003 \n  Education \n       Ulster University - Exchange, Business and Management · (2007 - 2008) \n Fachhochschule Augsburg (2003 - 2008) \n  Top Skills \n •	ABAP \n  •	SAP \n  •	SAP CRM "
    };
    this.backButton = this.backButton.bind(this);
  }

  componentWillMount() {}

  componentDidMount() {}
  backButton(){
    window.location.replace("/");
  }

  render() {
    return (
      <FadeIn>
        <button className="btn btn-warning backButton" onClick={this.backButton}>Back</button>
        <div className="profileSpacer"></div>
        <div className="profileWrapper">
          <div className="card">
            <h1 className="profileTitle">
              {this.state.firstName} {this.state.lastName}
            </h1>
          </div>

          <div className="row">
            <div className="column col-sm-3">
              <div className="profilePicWrapper">
                <img src={this.state.profilePic} alt="profilepic" />
              </div>

              <div className="profileDescriptionWrapper smallCard">
                <h3>Find me on</h3>
                <div>
                  <img className="soMeIcon" src={snapchatIcon} alt="snapchat" />
                  <img className="soMeIcon" src={facebookIcon} alt="facebook" />
                  <img
                    className="soMeIcon"
                    src={instagramIcon}
                    alt="instagram"
                  />
                  <img className="soMeIcon" src={tinderIcon} alt="tinder" />
                </div>
              </div>
            </div>

            <div className="column col-sm-7 profileSpacer">
              <div className="profileDescriptionWrapper card">
                <h3>Status</h3>
                <br />
                <h5>
                  Currently attending{" "}
                  <a href="https://events.sap.com/eur/coil-ml-hackathon-eu-north/en/registration.aspx">
                    SAP ML Hackathon!
                  </a> 
                </h5>
                <hr />
              </div>
              <div className="profileDescriptionWrapper card">
                <h3>Description</h3>
                <p>{this.state.profileDescription}</p>
                <hr />
              </div>

              <div className="profileDescriptionWrapper card">
                <h3>CV</h3>
                <br/>
                <p>
                  <h5>Profssional experience:</h5>
                  <ul>
                    <li>

                    Innologic A/S Manager September 2017 - Present  
                    </li>
                    <li>
                    Ecsact Analytics ApS Direktør, partner October 2012 - Present  
                    </li>
                    <li>
                    Codan 7 years 8 months 
                    </li>
                    <li>
                      {" "}
                      Nykredit A/S Analytiker / Souschef / Kundeanalytiker November 1996 - February 2005 
                    </li>
                  </ul>
                  <h5>Education</h5>
                  <ul>
                    <li>
                    IDA (Ingeniørforeningen i Danmark) Design Thinking · (2019 - 2019) 
                    </li>
                    <li>
                    University of Copenhagen Master (cand.scient.oecon), Mathematics, Economics, Statistics, Operations Research · (1991 - 1998) 
                    </li>
                    <li>
                    IMD Business School Building on Talent, General Management · (2002 - 2002)
                    </li>
                  </ul>
                  <h5>Top skills</h5>
                  <ul>
                    <li>Leading people </li>
                    <li>Statistics </li>
                    <li>Insurance</li>
                  </ul>
                </p>
                <hr/>
              </div>
            </div>

            <div className="column col-sm-2 alignRight">
              <div className="profileSideBarWrapper card">
                <center>
                  <h3>About:</h3>
                </center>
                <br />
                <h5>Work:</h5>
                <ul>
                  <li>I do insurance stuff</li>
                  </ul>
                  <br />
                  
                  <br />
                  <h5>Age: </h5>
                  <ul>
          
                  <li> Secret           
                  </li>
                  </ul>
                  <br />
                  <h5>Join date:</h5>
                  <ul>
                  <li>
                    26.09.2019{" "}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    );
  }
}

export default Profile;
