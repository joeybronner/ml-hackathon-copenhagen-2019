import React from 'react';
import FadeIn from 'react-fade-in';
import LoadAnim from './LoadAnim';
import ReactUploadImage from "./reactUpload.js";


class Home extends React.Component {
  constructor(props){
    super(props);

    this.onDrop = this.onDrop.bind(this);

    //State storage - should be hooked up with mongoose
   
   //We use OnLoadPost to get latest stored DB post. Intended to use with cancel button.
    this.state =  {
      pictures: [],
     isLoading: false
    };

    this.uploadFile = this.uploadFile.bind(this);
    this.postImage = this.postImage.bind(this);
  }
  

  componentWillMount(){
   
  }

  async onDrop(picture) {
   await this.setState({
        pictures: this.state.pictures.concat(picture),
    });
    this.forceUpdate();
    console.log(this.state.pictures);

    this.addFile2(this.state.pictures);
}

  addFile(event, image) {

    console.log(event.target.files);

    this.setState({isLoading: true});
    let currentURL = window.location.href;
    currentURL = currentURL.replace(":3000/", "");

    var formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append('name', 'some value user types');
    formData.append('description', 'some value user types');
    console.log(event.target.files[0]);

    fetch(currentURL + ":8000/api/FaceFeatureExtraction/extract/", {
method: 'POST',
headers: {'Content-Type':'multipart/form-data'},
body:event.target.files[0]
})
.then((response) => response.json())
.then((data)=>{
    this.setState({images: data.images, isLoading: false});
    this.setState({isLoading: false});
    this.props.updateImages(data.images);
})
.catch(error => this.setState({ error, isLoading: false}));
}


addFile2(image) {

  console.log(image);

  this.setState({isLoading: true});
  let currentURL = window.location.href;
  currentURL = currentURL.replace(":3000/", "");

  var formData = new FormData();
  formData.append("file", image[0]);
  formData.append('name', 'some value user types');
  formData.append('description', 'some value user types');
  console.log(image[0]);

  fetch(currentURL + ":8000/api/FaceFeatureExtraction/upload/", {
method: 'POST',
headers: {'Content-Type':'multipart/form-data'},
body:image[0]
})
.then((response) => response.json())
.then((data)=>{
  this.setState({images: data.images, isLoading: false});
  this.setState({isLoading: false});
  this.props.updateImages(data.images);
})
.catch(error => this.setState({ error, isLoading: false}));
}




  async postImage(image) {

    console.log(image);

    let currentURL = window.location.href;
    currentURL = currentURL.replace(":3000/", "");

    //Post/put to backend and refresh again
    let status = await fetch(currentURL + ":8000/api/FaceFeatureExtraction/upload/", {
      method: "POST",
      body: image,
      headers: {
        Accept: "application/json",
        "Content-Type": "image/jpg",
        pragma: "no-cache",
        "cache-control": "no-cache"
      }
    })
      .then(response => {
        return response.status;
      })
      .catch(e => {
        console.log(e);
      });

    return status;
  }



  uploadFile(imageContainer){
    console.log("I got here");

  
        console.log(imageContainer);

        if(imageContainer.length !== 0 && imageContainer !== undefined){

          this.postImage(imageContainer[0]);

        }
  }




  render() {
    return (
      <FadeIn>
      
         <h4 className="headerSubText">Inspirational people. One snap away.</h4>
        <div className="bodySpacer"></div>
       
        {!this.state.isLoading && (
         <center>
<ReactUploadImage />
          <br/>
          <h5>Click to image search for a matching profile!</h5>
        </center>
       
        )}            


        {this.state.isLoading &&
          <center>
          <LoadAnim />
          </center>}
      </FadeIn>
    );
  }
}



export default Home;
