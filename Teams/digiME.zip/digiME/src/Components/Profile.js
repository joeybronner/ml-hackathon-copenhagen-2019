import React from "react";

import FadeIn from "react-fade-in";
import profilePic from "../__public/profilepic.jpg";
import twitterIcon from "../__public/twitterIcon.png";
import facebookIcon from "../__public/facebookIcon.png";
import instagramIcon from "../__public/instagramIcon.png";
import linkedinIcon from "../__public/linkedinIcon.png";

class Profile extends React.Component {
  constructor(props) {
    super(props);

    //State storage - should be hooked up with mongoose

    //We use OnLoadPost to get latest stored DB post. Intended to use with cancel button.
    this.state = {
      firstName: "Christian",
      lastName: "Stemmer",
      profilePic: profilePic,
      profileDescription:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
      profileCV:
        "Professional experience \n Bouvet – Lead Developer (September 2010 – Present) \n Steadfast AS - SAP CRM Technical Consultant, October 2010 - Present \n SPV AG - SAP CRM Technical Consultant, April 2008 - September 2010 \n Media-Saturn Systemzentrale GmbH – Intern, March 2006 - July 2006 \n  Bauer AG – Apprenticeship, September 2000 - September 2003 \n  Education \n       Ulster University - Exchange, Business and Management · (2007 - 2008) \n Fachhochschule Augsburg (2003 - 2008) \n  Top Skills \n •	ABAP \n  •	SAP \n  •	SAP CRM "
    };
  }

  componentWillMount() {}

  componentDidMount() {}

  render() {
    return (
      <FadeIn>
        <div className="profileSpacer"></div>
        <div className="profileWrapper">
          <div className="card">
            <h1 className="profileTitle">
              {this.state.firstName} {this.state.lastName}
            </h1>
          </div>

          <div className="row">
            <div className="column col-sm-3">
              <div className="profilePicWrapper">
                <img src={this.state.profilePic} alt="profilepic" />
              </div>

              <div className="profileDescriptionWrapper smallCard">
                <h3>Find me on</h3>
                <div>
                  <img className="soMeIcon" src={twitterIcon} alt="twitter" />
                  <img className="soMeIcon" src={facebookIcon} alt="facebook" />
                  <img
                    className="soMeIcon"
                    src={instagramIcon}
                    alt="instagram"
                  />
                  <img className="soMeIcon" src={linkedinIcon} alt="linkedin" />
                </div>
              </div>
            </div>

            <div className="column col-sm-7 profileSpacer">
              <div className="profileDescriptionWrapper card">
                <h3>Status</h3>
                <br />
                <h5>
                  Currently attending{" "}
                  <a href="https://events.sap.com/eur/coil-ml-hackathon-eu-north/en/registration.aspx">
                    SAP ML Hackathon!
                  </a>{" "}
                </h5>
                <hr />
              </div>
              <div className="profileDescriptionWrapper card">
                <h3>Description</h3>
                <p>{this.state.profileDescription}</p>
                <hr />
              </div>

              <div className="profileDescriptionWrapper card">
                <h3>CV</h3>
                <br/>
                <p>
                  <h5>Profssional experience:</h5>
                  <ul>
                    <li>

                      Bouvet – Lead Developer (September 2010 – Present){" "}
                    </li>
                    <li>
                      Steadfast AS - SAP CRM Technical Consultant, October 2010
                      - Present{" "}
                    </li>
                    <li>
                      SPV AG - SAP CRM Technical Consultant, April 2008 -
                      September 2010{" "}
                    </li>
                    <li>
                      {" "}
                      Media-Saturn Systemzentrale GmbH – Intern, March 2006 -
                      July 2006{" "}
                    </li>
                    <li>
                      {" "}
                      Bauer AG – Apprenticeship, September 2000 - September 2003{" "}
                    </li>
                  </ul>
                  <h5>Education</h5>
                  <ul>
                    <li>
                      Ulster University - Exchange, Business and Management ·
                      (2007 - 2008){" "}
                    </li>
                    <li> Fachhochschule Augsburg (2003 - 2008) </li>
                  </ul>
                  <h5>Top skills</h5>
                  <ul>
                    <li>ABAP </li>
                    <li>SAP </li>
                    <li>SAP CRM </li>
                  </ul>
                </p>
                <hr/>
              </div>
              <div className="profileDescriptionWrapper card">
                <h3>Articles</h3>
                <p>
               
                </p>
                <hr />
              </div>
            </div>

            <div className="column col-sm-2 alignRight">
              <div className="profileSideBarWrapper card">
                <center>
                  <h3>About:</h3>
                </center>
                <br />
                <h5>Work:</h5>
                <ul>
                  <li> Developer Bouvet </li>
                  </ul>
                  <br />
                  <h5>Education:</h5>
                  <ul>
                  <li>
                   I went to school at some point...
                  </li>
                  </ul>
                  <br />
                  <h5>Age: </h5>
                  <ul>
          
                  <li> 38            
                  </li>
                  </ul>
                  <br />
                  <h5>Join date:</h5>
                  <ul>
                  <li>
                    26.09.2019{" "}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    );
  }
}

export default Profile;
