import React from 'react'
import cameraLogo from "../__public/cameraLogo.png";
import LoadAnim from './LoadAnim';

const axios = require("axios");

class ReactUploadImage extends React.Component {

    constructor(props) {
        super(props);
        this.state ={
            file: null,
            isLoading: false

        };
        this.onFormSubmit = this.onFormSubmit.bind(this);
        this.onChange = this.onChange.bind(this);
     
    }
    onFormSubmit(e){
        e.preventDefault();
        const formData = new FormData();
        formData.append('myImage',this.state.file);
        const config = {
            headers: {
                'content-type': 'multipart/form-data'
            }
        };

        let currentURL = window.location.href;
        currentURL = currentURL.replace(":3000/", "");
       
        axios.post(currentURL + ":8000/api/FaceFeatureExtraction/extract",formData,config)
            .then((response) => {
              console.log(response);


              console.log(response.data);

             

              if(response.data === "Clemet.jpg.txt"){
                console.log("CLEMET");
                window.location.replace("/0002");
              }
              else if(response.data === "Christian.JPG.txt") {
                window.location.replace("/0001");
              }
              else if(response.data === "Kenneth.jpg.txt"){
                window.location.replace("/0004");
              }
              else if(response.data === "Kjetil.jpg.txt"){
                window.location.replace("/0003");
              } 
                else if(response.data === "trump.jpg.txt"){
                window.location.replace("/Error");
              } 
              else{
                window.location.replace("/Error");
              }
              


            }).catch((error) => {
        });
    }
   async onChange(e) {
    
    await this.setState({file:e.target.files[0]});
    await this.setState({isLoading: true});
        this.onFormSubmit(e);
    }

    render() {
        return (
            <form onSubmit={this.onFormSubmit}>
              
              {!this.state.isLoading &&   <div className="btn btn-success cameraWrapper">
          <div className="image-upload">
                <label for="file-input">
              <img className="image" src={cameraLogo} alt="imageUpload" />
            </label>
            <input
              id="file-input"
              type="file"
              accept="image/x-png,image/gif,image/jpeg,image/*;capture=camera"
              onChange= {this.onChange}
            />
            </div></div>}

            {this.state.isLoading && <LoadAnim/>}

             
            </form>
        )
    }
}

export default ReactUploadImage