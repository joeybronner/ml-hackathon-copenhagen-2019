import React from "react";
import ReactLoading from "react-loading";

const LoadAnim = () => (
  <div className="col-centered loadAnimContainer">
    <ReactLoading
      className="loadAnim"
      type={"spin"}
      color={"white"}
      height={120}
      width={120}
    />
  </div>
);

export default LoadAnim;
