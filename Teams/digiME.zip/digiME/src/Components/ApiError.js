import React from "react";
import "./Error.css";
import FadeIn from "react-fade-in";

class ApiError extends React.Component {
  constructor(props){
    super(props);


    this.backButton = this.backButton.bind(this);
  }

  backButton(){
    window.location.replace("/");
  }

 

  render() {
    return (
      <FadeIn>
 <button className="btn btn-warning backButton" onClick={this.backButton}>Back</button>

        <div className="Errorbox">
        <div className="ErrorboxContent">
        <h3>Cannot find a profile match</h3>
        <br/>
        <h5>This could be due to:</h5>
        <ul>
          <li>Person is not a member of digiME</li>
          <li>The photograph was of insufficient detail or quality</li>
          </ul>
          <br/>
          <h5>If you want to try again:</h5>
          <ul>
          <li>Ensure that the face of the target person is clearly visible and takes up the majority of the viewfinder</li>
        </ul>

        </div>
        </div>
      </FadeIn>
    );
  }
}
export default ApiError;
