import React from "react";
import "./Style/bootswatchdarkly.css";
import logo from "./__public/digime-logo.png";

import { BrowserRouter as Router, Link } from "react-router-dom";
import { Switch, Route } from 'react-router'
import "./App.css";
import Profile from "./Components/Profile.js";
import Home from "./Components/Home.js";
import ApiError from "./Components/ApiError.js";
import Christian from "./Components/profiles/Christian";
import Clemet from "./Components/profiles/Clemet";
import Kjetil from "./Components/profiles/Kjetil";
import Kenneth from "./Components/profiles/Kenneth";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>
      <body>
       
     
      <Router>
      <div>
     <Switch>
        <Route exact path="/profile" component={Profile} />
        <Route exact path="/0001" component={Christian} />
        <Route exact path="/0002" component={Clemet} />
        <Route exact path="/0003" component={Kjetil} />
        <Route exact path="/0004" component={Kenneth} />
        <Route exact path="/error" component={ApiError} />
        <Route  path="/" component={Home} />
     </Switch>
      </div>
    </Router>
    </body>
    </div>
  );
}

export default App;
