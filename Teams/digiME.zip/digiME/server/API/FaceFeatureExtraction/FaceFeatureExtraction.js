const express     = require('express');
const router = express.Router();
var path        = require('path');
var fs          = require('fs');
var request     = require('request');
var multer      = require('multer');
var JSZip       = require("jszip");
var dotenv      = require('dotenv');




const storage = multer.diskStorage({
   destination: "./public/uploads/",
   filename: function(req, file, cb){
      cb(null,"IMAGE-" + Date.now() + path.extname(file.originalname));
   }
});

const upload = multer({
   storage: storage,
   limits:{fileSize: 1000000},
}).single("myImage");

router.post('/upload', function (req, res) {
  upload(req, res, function (err) {
      console.log("Request ---", req.body);
      console.log("Request file ---", req.file);//Here you get file.
      /*Now do where ever you want to do*/
      if(!err) {
          return res.send(200).end();
      }
  })
})


//we need some variables.
dotenv.config();
var APIKey            = process.env.APIKey;


exports.imageSearch = function(sourceImage, catalogPath, token, callback){
  console.log("imageSearch: " + sourceImage + "|" + catalogPath)
  extractFeatures(sourceImage, null, token, function(data){
    compare(catalogPath, data, token, callback);
  });
}


/*
Uploads a zip file and gets the features in a json file that we shouold save.
*/
var extractFeatures = function (filePath, outPath, token, cb){
  var formData = {
    files: fs.createReadStream(filePath)
  };
  sendAnyFile('https://mlftrial-face-feature-extractor.cfapps.eu10.hana.ondemand.com/api/v2alpha1/image/face-feature-extraction', filePath, token, cb, null);
}

var compare = function(predictionsPath, targetJSON, token, cb){
    var zip = new JSZip();

    //this is a function for uploading
    function saveZipIfDone () {
      zip
      .generateNodeStream({type:'nodebuffer',streamFiles:true})
      .pipe(fs.createWriteStream('predictions.zip'))
      .on('finish', function () {
          console.log("predictions.zip written.");
          var path = './predictions.zip';
          var options = {numSimilarVectors: 2};
          sendAnyFile('https://mlftrial-similarity-scoring.cfapps.eu10.hana.ondemand.com/api/v2/similarity-scoring', path, token, cb, options);
      });
    }

    //we can assume only one image for the moment
  var jsonTarget = JSON.parse(targetJSON).predictions[0];
  zip.file(jsonTarget.name + ".txt", JSON.stringify(jsonTarget.faces[0].face_feature));


  fs.readdir("./public/faces", (err, files) => {
    var length = files.length;
    var index = 0;
    files.forEach(file => {
      fs.readFile("./public/faces/" + file, function(err, data){
        var predictions = JSON.parse(data).predictions[0];
        console.log(predictions.name)
        zip.file(predictions.name + ".txt", JSON.stringify(predictions.faces[0].face_feature));
        index++;
        if(index == files.length){
          saveZipIfDone();
        }
      });
    });
  });

}

var sendAnyFile = function(url, zipPath, token, callback, options){
  console.log("sending ZIP to LML");
  var formData = {
    files: fs.createReadStream(zipPath)
  };

  if(options){
    formData.options = JSON.stringify(options);
  }

  request.post({
    url: url,
    formData: formData,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': token
    }
  }, function optionalCallback(err, httpResponse, body) {
      if (err) {
        return console.error('upload failed:', err);
      }

      callback(body);
  });
}

router.post("/extract", async (req, res) => {
  await upload(req, res, function (err) {
    console.log("Request ---", req.body);
    console.log("Request file ---", req.file);//Here you get file.
    /*Now do where ever you want to do*/

    if(!err) {

      setTimeout(() => {

        getBearerToken(exports.imageSearch, req, function(body){
          var result = JSON.parse(body).predictions[0].similarVectors[0].id;

          console.log(result);
          res.send(result);
        } );
    }, 3000)



        /*
      exports.imageSearch('./public/uploads/' + req.file.filename, './vektors', function(body){
        var result = JSON.parse(body).predictions[0].similarVectors[0].id;

        console.log(result);
        res.send(result);

      });
    }, 3000)
    */
  }

})



});


var getBearerToken = function(callback, req, cb2){
    var token = Buffer.from("sb-03c754aa-e2cf-473b-a9ac-b1e81d383e02!b23368|foundation-std-mlftrial!b3410" + ':' + "i2kSxy9rrBTai+/BG8Ariqv7oBA=").toString('base64');
    console.log(token)
    request.get({
      url: "https://s0012412948trial.authentication.eu10.hana.ondemand.com/oauth/token?grant_type=client_credentials",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Basic " + token
      }
    }, function optionalCallback(err, httpResponse, body) {
        if (err) {
          return console.error('failed:', err);
        }
        var auth_token = 'Bearer ' + (JSON.parse(body).access_token);

        callback('./public/uploads/' + req.file.filename, './vektors', auth_token, cb2);
  });
}

/*
var getBearerToken1 = function(callback, filePath){
    var token = Buffer.from("sb-03c754aa-e2cf-473b-a9ac-b1e81d383e02!b23368|foundation-std-mlftrial!b3410" + ':' + "i2kSxy9rrBTai+/BG8Ariqv7oBA=").toString('base64');
    console.log(token)
    request.get({
      url: "https://s0012412948trial.authentication.eu10.hana.ondemand.com/oauth/token?grant_type=client_credentials",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Basic " + token
      }
    }, function optionalCallback(err, httpResponse, body) {
        if (err) {
          return console.error('failed:', err);
        }
        var auth_token = 'Bearer ' + (JSON.parse(body).access_token);

        callback(auth_token, filePath, null, compare);
  });
}
*/

module.exports = router;
