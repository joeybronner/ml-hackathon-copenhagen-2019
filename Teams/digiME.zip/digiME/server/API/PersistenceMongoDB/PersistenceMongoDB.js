const express = require("express");
const router = express.Router();

const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://profile:profile@cluster0-ozahj.mongodb.net/test?retryWrites=true&w=majority"

router.post("/InsertProfile", (req, res) => {
    var mongodbOptions = new Object();
    mongodbOptions.useUnifiedTopology = true;
    mongodbOptions.useNewUrlParser = true;

    MongoClient.connect(uri, mongodbOptions, function(err, db) {
        if(err) {
            console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
        }
    
        var dbo = db.db("digiMe");
        var myobj = { name: "Company Inc", address: "Highway 37" };
    
        dbo.collection("customers").insertOne(myobj, function(err, res) {
            if(err) {
                console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
            }

            console.log("Document inserted");
            db.close();
        });
    });
});

router.get("/GetProfile", async (req, res) => {
    var mongodbOptions = new Object();
    mongodbOptions.useUnifiedTopology = true;

    let profileId = req.query.profileId;

      MongoClient.connect(uri, mongodbOptions, async function(err, db) {
        if(err) {
            console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
        }
        var dbo = db.db("digiMe");

      let result = await dbo.collection("customers").findOne({profileId: profileId});

            console.log(result);
            db.close();
            
            res.send(result);
        });
     
    });



module.exports = router;