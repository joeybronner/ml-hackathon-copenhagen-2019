const express = require("express");
const router = express.Router();




router.get("/test", (req, res) => {
  console.log("HEOI");
  res.send("test!");
});



module.exports = router;