const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const FaceFeatureExtraction = require("./API/FaceFeatureExtraction/FaceFeatureExtraction");
const PersistenceMongoDB = require("./API/PersistenceMongoDB/PersistenceMongoDB");


const app = express();
const port = 8000;

//const LocalDb = minimongo.MemoryDb;
//const db = new LocalDb();
//db.addCollection("profiles");

//ALLOW CROSS ORIGIN - Needed as long as React runs on seperate port
app.use(cors());
//app.use(bodyParser.raw({ inflate: true, limit: '100kb', type: 'application/form-data', useNewUrlParser: true }));


app.use("/api/FaceFeatureExtraction", FaceFeatureExtraction);
app.use("/api/PersistenceMongoDB", PersistenceMongoDB);



app.get("/api/hello", (req, res) => {
  console.log("Hi!");
  res.send("Hi!");
});


// Needed to serve built react-app
// app.use(express.static(path.join(__dirname, "../build")));

// Needed to support react router for built react app
// app.use("/__public", express.static(__dirname + "../__public")); // __ folders avoid react router

app.listen(port, () => console.log(`Listening on port ${port}`));
